//
//  WeatherApp.swift
//  Weather
//
//  Created by Harrinandhaan Sathish Kumaar Nirmala on 5/27/21.
//

import SwiftUI

@main
struct WeatherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
