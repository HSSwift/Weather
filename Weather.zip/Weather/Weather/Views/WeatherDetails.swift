//
//  Weather Details.swift
//  Weather
//
//  Created by Harrinandhaan Sathish Kumaar Nirmala on 5/27/21.
//

import SwiftUI

struct WeatherDetails: View {
    @State var icon: String
    @State var percent: String
    @State var info: String
    var body: some View {
        VStack() {
            Image(systemName: icon)
                .font(.headline)
                .padding(.top)
               
                
          Text(percent)
            .font(.headline)
            .fontWeight(.bold)
            
            
            Text(info)
                .font(.subheadline)
                .fontWeight(.semibold)
                .foregroundColor(.secondary)
        
        }
        .background(Color.white)
    }
}

struct WeatherDetails_Previews: PreviewProvider {
    static var previews: some View {
        WeatherDetails(icon: "eyeglasses", percent: "9.9 mi", info: "Visibility")
            .previewLayout(.sizeThatFits)
    }
}

struct TimeDetails: View {
    var body: some View {
        VStack() {
            Image(systemName: "sun.min")
                .font(.headline)
                .padding(.top)
               
                
          Text("56 F")
            .font(.headline)
            .fontWeight(.bold)
            
            
            Text("8:00 AM")
                .font(.subheadline)
                .fontWeight(.semibold)
                .foregroundColor(.secondary)
                .padding(.horizontal)
        
        }
        .cornerRadius(50)
    }
}
