//
//  DailyForecastView.swift
//  Weather
//
//  Created by Harrinandhaan Sathish Kumaar Nirmala on 5/27/21.
//

import SwiftUI

struct DailyForecast: View {
    @State var date: String
    @State var icon: String
    @State var high: String
    @State var low: String
    var body: some View {
        HStack {
            Text("Date")
                .padding(.horizontal)
            Spacer()
            Image(systemName: "sun.min")
            VStack {
                Text("84 F")
                Text("46 F")
            }
            .padding(.horizontal)
            
        }
    }
}

