//
//  Next7DayView.swift
//  Weather
//
//  Created by Harrinandhaan Sathish Kumaar Nirmala on 5/27/21.
//

import SwiftUI

struct NextDayView: View {
    @Environment(\.presentationMode) var presentationMode
    var body: some View {
        
        
       ScrollView {
            header
            
            Text("City Name")
                .font(.title)
                .fontWeight(.semibold)
        
        VStack(spacing: 16) {
          DailyForecast(date: "Jan 15", icon: "sun.min", high: "72", low: "45")
            DailyForecast(date: "Jan 16", icon: "cloud", high: "64", low: "38")
            DailyForecast(date: "Jan 17", icon: "cloud.sun.rain", high: "70", low: "43")
            DailyForecast(date: "Jan 18", icon: "cloud.rain", high: "68", low: "47")
            DailyForecast(date: "Jan 19", icon: "cloud.bolt.rain", high: "61", low: "38")


        }
        .padding()
        .background(RoundedRectangle(cornerRadius: 25.0).fill(Color.white).padding(.horizontal))
            
            Spacer()
        }
        .navigationBarHidden(true)
        .background(Color.black.opacity(0.04).ignoresSafeArea())
        
    }
    private var header: some View {
        HStack {
            Button(action: {
                presentationMode.wrappedValue.dismiss()
            }) {
                HStack {
                    Image(systemName: "chevron.left")
                    Text("Back")
                }
                .padding(.horizontal)
                .foregroundColor(.primary)
            }
            Spacer()
            
        }
    }
    
}

struct NextDayView_Previews: PreviewProvider {
    static var previews: some View {
        NextDayView()
    }
}
