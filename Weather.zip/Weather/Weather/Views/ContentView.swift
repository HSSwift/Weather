//
//  ContentView.swift
//  Weather
//
//  Created by Harrinandhaan Sathish Kumaar Nirmala on 5/27/21.
//

import SwiftUI

struct ContentView: View {
    @ObservedObject var cityVM = CityViewViewModel()
   
    var body: some View {
       
            ZStack {
                Color.black.opacity(0.04)
                VStack(spacing: 32) {
                    MenuHeaderView(cityVM: cityVM)
                        .padding(.top, 50)
                    header.padding(.top, 60)
                    TodayWeatherView(cityVM: cityVM)
                        .padding(.horizontal)
                    
                    informationBox
                    HourlyWeatherView(cityVM: cityVM)
                    
                    Spacer()
                }
            }
            .ignoresSafeArea()
        
    }
    private var informationBox: some View {
        HStack {
            HStack {
                WeatherDetails(icon: "eyeglasses", percent: "9.9 mi", info: "Visibility")
                WeatherDetails(icon: "eyeglasses", percent: "9.9 mi", info: "Visibility")
                WeatherDetails(icon: "eyeglasses", percent: "9.9 mi", info: "Visibility")
                WeatherDetails(icon: "eyeglasses", percent: "9.9 mi", info: "Visibility")
            }
            .padding()
        
        }
        .background(RoundedRectangle(cornerRadius: 25).fill(Color.white))
    }
    private var header: some View {
        VStack {

            Text(cityVM.city)
                    .font(.system(size: 25))
                    .fontWeight(.bold)
                
            Text(cityVM.date)
                    .font(.headline)
                    .fontWeight(.semibold)
            
        }
    }
    private var dailyForecast: some View {
        VStack {
            HStack {
                Text("Today")
                    .font(.headline)
                    .padding(.horizontal)
                    
                Spacer()
                NavigationLink(destination: NextDayView()) {
                    HStack {
                        Text("Next 7 Days")
                        Image(systemName: "chevron.right")
                    }
                    .foregroundColor(.black)

                }
                .font(.headline)
                .padding(.horizontal)
            }
            ScrollView(.horizontal, showsIndicators: false) {
                HStack {
                    TimeDetails()
                    TimeDetails()
                    TimeDetails()
                    TimeDetails()
                    TimeDetails()
                    TimeDetails()
                    TimeDetails()
                    TimeDetails()
                }
            }
        }
    }
    private var currentForecast: some View {
        VStack {
            Text("Friday, January 15, 2021")
            
            HStack {
                
                Text("72")
                    .font(.system(size: 50))
                    .padding(.top)
            }
                
            HStack {
               
                Text("sunny")
                    .padding()
            }
            .font(.title)
        }
        
        .background(RoundedRectangle(cornerRadius: 25).fill(Color.white))
       
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
