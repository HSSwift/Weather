//
//  Temperature.swift
//  Weather
//
//  Created by Harrinandhaan Sathish Kumaar Nirmala on 5/28/21.
//

import Foundation

struct Temperature: Codable {
    var min: Double
    var max: Double
}
