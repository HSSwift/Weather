//
//  WeatherDetail.swift
//  Weather
//
//  Created by Harrinandhaan Sathish Kumaar Nirmala on 5/28/21.
//

import Foundation

struct WeatherDetail: Codable {
    var main: String
    var description: String
    var icon: String
}
