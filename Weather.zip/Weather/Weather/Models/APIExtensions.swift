//
//  APIExtensions.swift
//  Weather
//
//  Created by Harrinandhaan Sathish Kumaar Nirmala on 5/28/21.
//

import Foundation

extension API {
    static let baseURLString = "https://api.openweathermap.org/data/2.5"
    static func getURLFor(lat: Double, lon: Double) -> String {
        return "\(baseURLString)oncall?lat=\(lat)&lon=\(lon)&exclude=minutely%appid=\(API.apikey)&units=imperial"
    }
}
