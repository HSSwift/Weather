//
//  Statics.swift
//  Weather
//
//  Created by Harrinandhaan Sathish Kumaar Nirmala on 5/28/21.
//

import Foundation

enum API {
    static let apikey = "012b5b467deb0a283715da8dae42c004"
}
