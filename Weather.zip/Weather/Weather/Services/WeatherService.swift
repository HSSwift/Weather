//
//  WeatherService.swift
//  Weather
//
//  Created by Harrinandhaan Sathish Kumaar Nirmala on 5/28/21.
//
import Combine
import Foundation

struct WeatherService {
    static func getWeatherData(lat: Double, long: Double) -> AnyPublisher<WeatherData, Error> {
        
        
        return URLSession.shared
            .dataTaskPublisher(for: url)
            .tryMap() { element -> Data in
                    guard let httpResponse = element.response as? HTTPURLResponse,
                        httpResponse.statusCode == 200 else {
                            throw URLError(.badServerResponse)
                        }
                    return element.data
                
                    }
                .decode(type: WeatherData.self, decoder: JSONDecoder())
            .eraseToAnyPublisher()
    }
}
